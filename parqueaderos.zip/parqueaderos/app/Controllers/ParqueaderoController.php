<?php

namespace App\Controllers;

use App\Models\VehiculoModel;
use App\Models\ConductorModel;
use App\Models\PuestoParqueoModel;

class ParqueaderoController extends BaseController

{
    public function index()
    {
        return view('parqueadero/agregar_vehiculo')
        ;
    }
    public function Conductor()
    {
        return view('parqueadero/index')
        ;
    }
    public function puesto()
    {
        return view('parqueadero/asignar_puesto')
        ;
    }
    

    
    public function registrarConductor()
    {
        // Obtener datos del formulario
        $nombre = $this->request->getPost('nombre');
        $direccion = $this->request->getPost('direccion');
        $telefono = $this->request->getPost('telefono');
        $placa = $this->request->getPost('placa');

        // Cargar modelos
        $conductorModel = new ConductorModel();
        $vehiculoModel = new VehiculoModel();

        // Guardar conductor
        $conductorData = [
            'nombre' => $nombre,
            'direccion' => $direccion,
            'telefono' => $telefono
        ];
        $conductorId = $conductorModel->insert($conductorData);

        // Guardar vehículo asociado al conductor
        $vehiculoData = [
            'placa' => $placa,
            
        ];
        $vehiculoModel->insert($vehiculoData);

        // Redireccionar o mostrar un mensaje de éxito
        return redirect()->to('asignar');
    }

    public function registrarVehiculo()
    {
        // Obtener datos del formulario
        $placa = $this->request->getPost('placa');
        $marca = $this->request->getPost('marca');
        $modelo = $this->request->getPost('modelo');
        $color = $this->request->getPost('color');

        // Cargar modelo
        $vehiculoModel = new VehiculoModel();

        // Guardar vehículo
        $vehiculoData = [
            'placa' => $placa,
            'marca' => $marca,
            'modelo' => $modelo,
            'color' => $color
        ];
        $vehiculoModel->insert($vehiculoData);

        // Redireccionar o mostrar un mensaje de éxito
        return redirect()->to('exito');
    }

    public function asignarPuesto()
    {
        // Obtener datos del formulario
        $vehiculoId = $this->request->getPost('vehiculo');
        $puestoId = $this->request->getPost('puesto');

        // Cargar modelos
        $vehiculoModel = new VehiculoModel();
        $puestoParqueoModel = new PuestoParqueoModel();

        // Asignar el vehículo al puesto
        $puesto = $puestoParqueoModel->find($puestoId);
        $puesto->disponible = false;
        $puesto->vehiculo_id = $vehiculoId;
        $puestoParqueoModel->save($puesto);

        // Redireccionar o mostrar un mensaje de éxito
        return redirect()->to(base_url())->with('success', 'Puesto asignado exitosamente');
    }

    public function listarPuestos()
    {
        // Cargar modelo
        $puestoParqueoModel = new PuestoParqueoModel();

        // Obtener todos los puestos
        $puestos = $puestoParqueoModel->findAll();

        // Cargar la vista con los datos
        return view('listar_puestos', ['puestos' => $puestos]);
    }
}
