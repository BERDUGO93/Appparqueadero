<!DOCTYPE html>
<html>
<head>
    <title>Asignar Puesto de Parqueo</title>
</head>
<body>
    <h1>Asignar Puesto de Parqueo</h1>

    <form method="post" action="<?php echo base_url('parqueadero/asignar_puesto'); ?>">
        <label for="vehiculo">Vehículo:</label>
        <select name="vehiculo" id="vehiculo" required>
            <?php foreach ($vehiculos as $vehiculo): ?>
                <option value="<?php echo $vehiculo->id; ?>"><?php echo $vehiculo->placa; ?></option>
            <?php endforeach; ?>
        </select>

        <label for="puesto">Puesto de Parqueo:</label>
        <select name="puesto" id="puesto" required>
            <?php foreach ($puestos as $puesto): ?>
                <option value="<?php echo $puesto->id; ?>"><?php echo $puesto->numero; ?></option>
            <?php endforeach; ?>
        </select>

        <input type="submit" value="Asignar">
    </form>

    <h2>Lista de Puestos de Parqueo</h2>

    <table>
        <thead>
            <tr>
                <th>Número de Puesto</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($puestos as $puesto): ?>
                <tr>
                    <td><?php echo $puesto->numero; ?></td>
                    <td><?php echo $puesto->disponible ? 'Disponible' : 'No disponible'; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>

</html>

