<!DOCTYPE html>
<html>
<head>
    <title>Registro de Conductor</title>
</head>
<body>
    <h1>Registro de Conductor</h1>

    <form method="post" action="<?php echo base_url('parqueadero/registrarC'); ?>">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" id="nombre" required>

        <label for="direccion">Dirección:</label>
        <input type="text" name="direccion" id="direccion" required>

        <label for="telefono">Teléfono:</label>
        <input type="text" name="telefono" id="telefono" required>

        <label for="placa">Placa del Vehículo:</label>
        <input type="text" name="placa" id="placa" required>

        <input type="submit" value="Registrar">
    </form>
</body>
</html>
