<!DOCTYPE html>
<html>
<head>
    <title>Registro de Vehículo</title>
</head>
<body>
    <h1>Registro de Vehículo</h1>

    <form method="post" action="<?php echo base_url('parqueadero/registrar'); ?>">
        <label for="placa">Placa:</label>
        <input type="text" name="placa" id="placa" required>

        <label for="marca">Marca:</label>
        <input type="text" name="marca" id="marca" required>

        <label for="modelo">Modelo:</label>
        <input type="text" name="modelo" id="modelo" required>

        <label for="color">Color:</label>
        <input type="text" name="color" id="color" required>

        <input type="submit" value="Registrar">
    </form>
</body>
</html>
