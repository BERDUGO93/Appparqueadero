<?php

namespace App\Models;

use CodeIgniter\Model;

class VehiculoModel extends Model
{
    protected $table = 'Vehiculo';
    protected $primaryKey = 'id';
    protected $allowedFields = ['placa', 'marca', 'modelo', 'color'];
}
