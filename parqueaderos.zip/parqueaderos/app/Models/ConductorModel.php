<?php

namespace App\Models;

use CodeIgniter\Model;

class ConductorModel extends Model
{
    protected $table = 'Conductor';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nombre', 'direccion', 'telefono', 'vehiculo_id'];
}
