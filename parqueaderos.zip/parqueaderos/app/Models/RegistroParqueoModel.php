<?php

namespace App\Models;

use CodeIgniter\Model;

class RegistroParqueoModel extends Model
{
    protected $table = 'RegistroParqueo';
    protected $primaryKey = 'id';
    protected $allowedFields = ['vehiculo_id', 'fecha_entrada', 'fecha_salida', 'valor_pago'];
}
