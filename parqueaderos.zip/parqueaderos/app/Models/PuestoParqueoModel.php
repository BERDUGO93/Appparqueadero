<?php

namespace App\Models;

use CodeIgniter\Model;

class PuestoParqueoModel extends Model
{
    protected $table = 'PuestoParqueo';
    protected $primaryKey = 'id';
    protected $allowedFields = ['numero', 'disponible', 'vehiculo_id'];
}
