-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-06-2023 a las 16:53:35
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `parkingdb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parqueaderos`
--

CREATE TABLE `parqueaderos` (
  `id_parqueadero` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `capacidad_total` int(11) DEFAULT NULL,
  `capacidad_disponible` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `parqueaderos`
--

INSERT INTO `parqueaderos` (`id_parqueadero`, `nombre`, `capacidad_total`, `capacidad_disponible`) VALUES
(1, 'automovil', 20, 20),
(2, 'camionetas', 20, 20),
(3, 'motocicletas', 40, 40);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puestos`
--

CREATE TABLE `puestos` (
  `id_puesto` int(11) NOT NULL,
  `id_parqueadero` int(11) DEFAULT NULL,
  `numero_puesto` int(11) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `puestos`
--

INSERT INTO `puestos` (`id_puesto`, `id_parqueadero`, `numero_puesto`, `estado`) VALUES
(1, 1, 1, 'Disponible'),
(2, 1, 2, 'Disponible'),
(3, 1, 3, 'Disponible'),
(4, 1, 4, 'Disponible'),
(5, 1, 5, 'Disponible'),
(6, 1, 6, 'Disponible'),
(7, 1, 7, 'Disponible'),
(8, 1, 8, 'Disponible'),
(9, 1, 9, 'Disponible'),
(10, 1, 10, 'Disponible'),
(11, 1, 11, 'Disponible'),
(12, 1, 12, 'Disponible'),
(13, 1, 13, 'Disponible'),
(14, 1, 14, 'Disponible'),
(15, 1, 15, 'Disponible'),
(16, 1, 16, 'Disponible'),
(17, 1, 17, 'Disponible'),
(18, 1, 18, 'Disponible'),
(19, 1, 19, 'Disponible'),
(20, 1, 20, 'Disponible'),
(21, 2, 1, 'Disponible'),
(22, 2, 2, 'Disponible'),
(23, 2, 3, 'Disponible'),
(24, 2, 4, 'Disponible'),
(25, 2, 5, 'Disponible'),
(26, 2, 6, 'Disponible'),
(27, 2, 7, 'Disponible'),
(28, 2, 8, 'Disponible'),
(29, 2, 9, 'Disponible'),
(30, 2, 10, 'Disponible'),
(31, 2, 11, 'Disponible'),
(32, 2, 12, 'Disponible'),
(33, 2, 13, 'Disponible'),
(34, 2, 14, 'Disponible'),
(35, 2, 15, 'Disponible'),
(36, 2, 16, 'Disponible'),
(37, 2, 17, 'Disponible'),
(38, 2, 18, 'Disponible'),
(39, 2, 19, 'Disponible'),
(40, 2, 20, 'Disponible'),
(41, 3, 1, 'Disponible'),
(42, 3, 2, 'Disponible'),
(43, 3, 3, 'Disponible'),
(44, 3, 4, 'Disponible'),
(45, 3, 5, 'Disponible'),
(46, 3, 6, 'Disponible'),
(47, 3, 7, 'Disponible'),
(48, 3, 8, 'Disponible'),
(49, 3, 9, 'Disponible'),
(50, 3, 10, 'Disponible'),
(51, 3, 11, 'Disponible'),
(52, 3, 12, 'Disponible'),
(53, 3, 13, 'Disponible'),
(54, 3, 14, 'Disponible'),
(55, 3, 15, 'Disponible'),
(56, 3, 16, 'Disponible'),
(57, 3, 17, 'Disponible'),
(58, 3, 18, 'Disponible'),
(59, 3, 19, 'Disponible'),
(60, 3, 20, 'Disponible'),
(61, 3, 21, 'Disponible'),
(62, 3, 22, 'Disponible'),
(63, 3, 23, 'Disponible'),
(64, 3, 24, 'Disponible'),
(65, 3, 25, 'Disponible'),
(66, 3, 26, 'Disponible'),
(67, 3, 27, 'Disponible'),
(68, 3, 28, 'Disponible'),
(69, 3, 29, 'Disponible'),
(70, 3, 30, 'Disponible'),
(71, 3, 31, 'Disponible'),
(72, 3, 32, 'Disponible'),
(73, 3, 33, 'Disponible'),
(74, 3, 34, 'Disponible'),
(75, 3, 35, 'Disponible'),
(76, 3, 36, 'Disponible'),
(77, 3, 37, 'Disponible'),
(78, 3, 38, 'Disponible'),
(79, 3, 39, 'Disponible'),
(80, 3, 40, 'Disponible');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--

CREATE TABLE `registro` (
  `id_registro` int(11) NOT NULL,
  `id_puesto` int(11) DEFAULT NULL,
  `Placa` varchar(6) DEFAULT NULL,
  `fecha_entrada` datetime DEFAULT NULL,
  `fecha_salida` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifas`
--

CREATE TABLE `tarifas` (
  `id_tarifa` int(11) NOT NULL,
  `tipo_vehiculo` varchar(50) DEFAULT NULL,
  `tarifa_hora` decimal(8,2) DEFAULT NULL,
  `tarifa_dia` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tarifas`
--

INSERT INTO `tarifas` (`id_tarifa`, `tipo_vehiculo`, `tarifa_hora`, `tarifa_dia`) VALUES
(1, 'Automóvil', 2300.00, 20000.00),
(2, 'Motocicleta', 1500.00, 15000.00),
(3, 'Camioneta', 3000.00, 30000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculos`
--

CREATE TABLE `vehiculos` (
  `id_vehiculo` varchar(6) NOT NULL,
  `tipo_vehiculo` varchar(50) DEFAULT NULL,
  `Conductor` varchar(200) NOT NULL,
  `Docconductor` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `parqueaderos`
--
ALTER TABLE `parqueaderos`
  ADD PRIMARY KEY (`id_parqueadero`);

--
-- Indices de la tabla `puestos`
--
ALTER TABLE `puestos`
  ADD PRIMARY KEY (`id_puesto`),
  ADD KEY `id_parqueadero` (`id_parqueadero`);

--
-- Indices de la tabla `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`id_registro`),
  ADD KEY `id_puesto` (`id_puesto`),
  ADD KEY `registro_infk_2` (`Placa`);

--
-- Indices de la tabla `tarifas`
--
ALTER TABLE `tarifas`
  ADD PRIMARY KEY (`id_tarifa`);

--
-- Indices de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD PRIMARY KEY (`id_vehiculo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `registro`
--
ALTER TABLE `registro`
  MODIFY `id_registro` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `puestos`
--
ALTER TABLE `puestos`
  ADD CONSTRAINT `puestos_ibfk_1` FOREIGN KEY (`id_parqueadero`) REFERENCES `parqueaderos` (`id_parqueadero`);

--
-- Filtros para la tabla `registro`
--
ALTER TABLE `registro`
  ADD CONSTRAINT `registro_ibfk_1` FOREIGN KEY (`id_puesto`) REFERENCES `puestos` (`id_puesto`),
  ADD CONSTRAINT `registro_infk_2` FOREIGN KEY (`Placa`) REFERENCES `vehiculos` (`id_vehiculo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
