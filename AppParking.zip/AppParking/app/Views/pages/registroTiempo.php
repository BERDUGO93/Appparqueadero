<body>
  <div class="container">
    <h1>Registro de Tiempo</h1>
    <form>
      
      <div class="form-group">
        <label for="id_puesto"> Puesto</label>
        <input type="text" class="form-control" id="id_puesto" name="id_puesto" required>
      </div>
      <div class="form-group">
        <label for="id_vehiculo">Placa de Vehículo</label>
        <input type="text" class="form-control" id="id_vehiculo" name="id_vehiculo" required>
      </div>
      <div class="form-group">
        <label for="fecha_entrada">Fecha de Entrada</label>
        <input type="datetime-local" class="form-control" id="fecha_entrada" name="fecha_entrada" required>
      </div>
      <div class="form-group">
        <label for="fecha_salida">Fecha de Salida</label>
        <input type="datetime-local" class="form-control" id="fecha_salida" name="fecha_salida" required>
      </div>
      <button type="submit" class="btn btn-primary">Registrar</button>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>