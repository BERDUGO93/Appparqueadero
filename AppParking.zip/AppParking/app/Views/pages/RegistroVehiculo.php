<body>
  <div class="container">
    <h2>Formulario de Registro de Vehículo</h2>
    <form method="post" action="RegistroV">
      <div class="form-group">
        <label for="nombre">Nombre del Conductor:</label>
        <input type="text" class="form-control" id="nombre" name="nombre" required>
      </div>
      <div class="form-group">
        <label for="documento">Documento del Conductor:</label>
        <input type="text" class="form-control" id="documento" name="documento" required>
      </div>
      <div class="form-group">
        <label for="placa">Placa:</label>
        <input type="text" class="form-control" id="placa" name="placa" required>
      </div>
      <div class="form-group">
        <label for="tipo">Tipo de Vehículo:</label>
        <select class="form-control" id="tipo" name="tipo" required>
          <option value="">Seleccione un tipo de vehículo</option>
          <option value="automovil">Automóvil</option>
          <option value="motocicleta">Motocicleta</option>
          <option value="camioneta">Camión</option>
          <option value="Bicicleta">Autobús</option>
          <option value="otro">Otro</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary">Enviar</button>
    </form>
  </div>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>