<?php

namespace App\Models;

use CodeIgniter\Model;

class nuevovehiculo extends Model
{
    protected $table = 'vehiculos';
    protected $primaryKey = 'id_vehiculo';
    protected $allowedFields = ['documento', 'nombre', 'placa', 'tipo'];


    

    
}