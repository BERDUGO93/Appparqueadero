<?php

namespace App\Controllers;

class registrotiempo extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }
}