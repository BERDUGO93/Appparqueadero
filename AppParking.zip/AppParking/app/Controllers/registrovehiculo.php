<?php

namespace App\Controllers;
use App\Models\nuevovehiculo;


class registrovehiculo extends BaseController
{
    public function index()
    {
        return view('templates/header')
        . view('pages/RegistroVehiculo')
        . view('templates/footer');;
    }

    public function registrar()
    {
        // Recibe los datos del formulario
        $documento = $this->request->getPost('documento');
        $nombre = $this->request->getPost('nombre');
        $placa = $this->request->getPost('placa');
        $tipo = $this->request->getPost('tipo');
        
        

      


        // Crea una instancia del modelo de usuarios
        $model = new nuevovehiculo();

        // Inserta los datos en la base de datos
        $data = [
            'documento' => $documento,
            'nombre' => $nombre,
            'placa' => $placa,
            'tipo' => $tipo,
            
        ];
        $model->insert($data);

        // Redirige a la página de éxito o muestra un mensaje
        return redirect()->to('exito');
    }

    public function exito()
    {
        return view('templates/header')
        . view('pages/registroTiempo')
        . view('templates/footer');;
    }
}